Fruta<- "maçã"

lista_frutas <- c("maçã","mamão", "laranja")

